package com.axelin.se_calculadorajerarquica

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.util.ArrayDeque

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    ExpressionCalculatorScreen()
                }
            }
        }
    }
}

/* ==========================
 *  EXPRESIÓN: PARSER + EVAL
 * ========================== */

private object Expr {

    private val mc = MathContext(16, RoundingMode.HALF_UP)

    private sealed interface Tok {
        data class Num(val v: BigDecimal): Tok
        data class Op(val kind: OpKind): Tok
        data object LParen: Tok
        data object RParen: Tok
    }

    private enum class OpKind(val sym: String, val prec: Int, val rightAssoc: Boolean) {
        ADD("+", 1, false),
        SUB("-", 1, false),
        MUL("*", 2, false),
        DIV("/", 2, false),
        NEG("NEG", 3, true)
    }

    private fun tokenize(expr: String): List<Tok> {
        val out = mutableListOf<Tok>()
        var i = 0
        var prev: Tok? = null

        fun isUnaryMinus(): Boolean =
            prev == null || prev is Tok.Op || prev is Tok.LParen

        while (i < expr.length) {
            val c = expr[i]
            when {
                c.isWhitespace() -> i++

                c.isDigit() || c == '.' || (c == '-' && isUnaryMinus()) -> {
                    val start = i
                    var hasSign = false
                    if (c == '-' && isUnaryMinus()) { i++; hasSign = true }
                    var hasDot = false
                    var j = i
                    while (j < expr.length) {
                        val ch = expr[j]
                        if (ch.isDigit()) j++
                        else if (ch == '.' && !hasDot) { hasDot = true; j++ }
                        else break
                    }
                    if (j == i) {
                        out += Tok.Op(OpKind.NEG)
                        prev = out.last()
                        continue
                    }
                    val numStr = (if (hasSign) "-" else "") + expr.substring(i, j)
                    val bd = numStr.toBigDecimalOrNull()
                        ?: throw IllegalArgumentException("Número inválido cerca de: ${expr.substring(start)}")
                    out += Tok.Num(bd)
                    prev = out.last()
                    i = j
                }

                c == '+' || c == '-' || c == '*' || c == '/' -> {
                    val kind = when (c) {
                        '+' -> OpKind.ADD
                        '-' -> OpKind.SUB
                        '*' -> OpKind.MUL
                        else -> OpKind.DIV
                    }
                    out += Tok.Op(kind)
                    prev = out.last()
                    i++
                }

                c == '(' -> { out += Tok.LParen; prev = out.last(); i++ }
                c == ')' -> { out += Tok.RParen; prev = out.last(); i++ }

                else -> throw IllegalArgumentException("Símbolo inválido: '$c'")
            }
        }
        return out
    }

    private fun toRpn(tokens: List<Tok>): List<Tok> {
        val output = mutableListOf<Tok>()
        val stack = ArrayDeque<Tok>()

        fun peekOpKind(): OpKind? = (stack.peek() as? Tok.Op)?.kind

        for (t in tokens) {
            when (t) {
                is Tok.Num -> output += t
                is Tok.Op -> {
                    val tk = t.kind
                    while (true) {
                        val top = peekOpKind() ?: break
                        val cond = if (tk.rightAssoc) {
                            tk.prec < top.prec
                        } else {
                            tk.prec <= top.prec
                        }
                        if (cond) output += stack.pop() as Tok.Op else break
                    }
                    stack.push(t)
                }
                Tok.LParen -> stack.push(t)
                Tok.RParen -> {
                    while (stack.isNotEmpty() && stack.peek() !is Tok.LParen) {
                        output += stack.pop() as Tok.Op
                    }
                    if (stack.isEmpty() || stack.peek() !is Tok.LParen) {
                        throw IllegalArgumentException("Paréntesis desbalanceados")
                    }
                    stack.pop()
                    if (stack.peek() is Tok.Op && (stack.peek() as Tok.Op).kind == OpKind.NEG) {
                        output += stack.pop() as Tok.Op
                    }
                }
            }
        }
        while (stack.isNotEmpty()) {
            val t = stack.pop()
            if (t is Tok.LParen || t is Tok.RParen) throw IllegalArgumentException("Paréntesis desbalanceados")
            output += t as Tok.Op
        }
        return output
    }

    private fun evalRpn(rpn: List<Tok>): BigDecimal {
        val st = ArrayDeque<BigDecimal>()
        for (t in rpn) {
            when (t) {
                is Tok.Num -> st.push(t.v)
                is Tok.Op -> when (t.kind) {
                    OpKind.NEG -> {
                        val a = st.popOrError("Falta operando para NEG")
                        st.push(a.negate(mc))
                    }
                    OpKind.ADD, OpKind.SUB, OpKind.MUL, OpKind.DIV -> {
                        val b = st.popOrError("Falta operando derecho")
                        val a = st.popOrError("Falta operando izquierdo")
                        val res = when (t.kind) {
                            OpKind.ADD -> a.add(b, mc)
                            OpKind.SUB -> a.subtract(b, mc)
                            OpKind.MUL -> a.multiply(b, mc)
                            OpKind.DIV -> {
                                if (b.compareTo(BigDecimal.ZERO) == 0)
                                    throw ArithmeticException("División por cero")
                                a.divide(b, 12, RoundingMode.HALF_UP)
                            }
                            else -> error("Nunca llega")
                        }
                        st.push(res)
                    }
                }
                else -> {}
            }
        }
        if (st.size != 1) throw IllegalArgumentException("Expresión inválida")
        return st.pop()
    }

    private fun <T> ArrayDeque<T>.popOrError(msg: String): T =
        if (isEmpty()) throw IllegalArgumentException(msg) else pop()

    fun evaluate(expr: String): BigDecimal {
        val tokens = tokenize(expr)
        val rpn = toRpn(tokens)
        return evalRpn(rpn)
    }

    fun fmt(bd: BigDecimal, maxScale: Int = 10): String {
        val stripped = bd.stripTrailingZeros()
        val scaled = stripped.setScale(
            minOf(maxScale, maxOf(0, stripped.scale())),
            RoundingMode.HALF_UP
        )
        val text = scaled.stripTrailingZeros().toPlainString()
        return if (text == "-0") "0" else text
    }
}

/* ==================
 *  UI CON COMPOSE
 * ================== */

@Composable
private fun ExpressionCalculatorScreen() {
    var expression by remember { mutableStateOf("") }
    var resultText by remember { mutableStateOf("0") }
    var errorText by remember { mutableStateOf<String?>(null) }

    fun recalc() {
        errorText = null
        if (expression.isBlank()) { resultText = "0"; return }
        try {
            val value = Expr.evaluate(expression.replace('×','*').replace('÷','/'))
            resultText = Expr.fmt(value)
        } catch (_: Exception) {
            // no hacer nada si la expresión está incompleta o inválida
        }
    }

    fun press(s: String) { expression += s; recalc() }
    fun del() { if (expression.isNotEmpty()) { expression = expression.dropLast(1); recalc() } }
    fun clearAll() { expression = ""; resultText = "0"; errorText = null }
    fun equalsNow() {
        try {
            val value = Expr.evaluate(expression.replace('×','*').replace('÷','/'))
            resultText = Expr.fmt(value)
            expression = resultText
            errorText = null
        } catch (e: Exception) {
            errorText = e.message ?: "Error"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.BottomEnd
        ) {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = expression.ifBlank { " " },
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    maxLines = 2
                )
                Text(
                    text = if (errorText != null) "Error: $errorText" else resultText,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Light,
                    textAlign = TextAlign.End,
                    lineHeight = 48.sp
                )
            }
        }

        val rowMod = Modifier.fillMaxWidth()
        val gap = 8.dp

        Column(verticalArrangement = Arrangement.spacedBy(gap)) {
            Row(rowMod, horizontalArrangement = Arrangement.spacedBy(gap)) {
                CalcButton("AC", Modifier.weight(1f)) { clearAll() }
                CalcButton("⌫", Modifier.weight(1f)) { del() }
                CalcButton("(",  Modifier.weight(1f)) { press("(") }
                CalcButton(")",  Modifier.weight(1f)) { press(")") }
            }
            Row(rowMod, horizontalArrangement = Arrangement.spacedBy(gap)) {
                CalcButton("7", Modifier.weight(1f)) { press("7") }
                CalcButton("8", Modifier.weight(1f)) { press("8") }
                CalcButton("9", Modifier.weight(1f)) { press("9") }
                CalcButton("÷", Modifier.weight(1f)) { press("÷") }
            }
            Row(rowMod, horizontalArrangement = Arrangement.spacedBy(gap)) {
                CalcButton("4", Modifier.weight(1f)) { press("4") }
                CalcButton("5", Modifier.weight(1f)) { press("5") }
                CalcButton("6", Modifier.weight(1f)) { press("6") }
                CalcButton("×", Modifier.weight(1f)) { press("×") }
            }
            Row(rowMod, horizontalArrangement = Arrangement.spacedBy(gap)) {
                CalcButton("1", Modifier.weight(1f)) { press("1") }
                CalcButton("2", Modifier.weight(1f)) { press("2") }
                CalcButton("3", Modifier.weight(1f)) { press("3") }
                // aquí ya está corregido con "-" normal
                CalcButton("-", Modifier.weight(1f)) { press("-") }
            }
            Row(rowMod, horizontalArrangement = Arrangement.spacedBy(gap)) {
                CalcButton("0", Modifier.weight(2f)) { press("0") }
                CalcButton(".", Modifier.weight(1f)) { press(".") }
                CalcButton("+", Modifier.weight(1f)) { press("+") }
            }
            Row(rowMod, horizontalArrangement = Arrangement.spacedBy(gap)) {
                CalcButton("=", Modifier.weight(1f)) { equalsNow() }
            }
        }
    }
}

@Composable
private fun CalcButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(64.dp),
        shape = MaterialTheme.shapes.extraLarge
    ) {
        Text(label, fontSize = 22.sp)
    }
}
