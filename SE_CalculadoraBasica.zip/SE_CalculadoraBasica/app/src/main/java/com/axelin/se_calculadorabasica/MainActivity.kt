package com.axelin.se_calculadorabasica

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CalculatorScreen()
                }
            }
        }
    }
}

private enum class Operation { ADD, SUBTRACT, MULTIPLY, DIVIDE }

@Composable
private fun CalculatorScreen() {
    val mc = remember { MathContext(16, RoundingMode.HALF_UP) }

    data class CalcState(
        val display: String = "0",
        val pendingOp: Operation? = null,
        val accumulator: BigDecimal? = null,
        val clearOnNext: Boolean = false
    )

    var state by remember { mutableStateOf(CalcState()) }

    fun toBD(s: String): BigDecimal =
        s.toBigDecimalOrNull() ?: BigDecimal.ZERO

    fun fmt(bd: BigDecimal): String {
        val s = bd.stripTrailingZeros().toPlainString()
        return if (s == "-0") "0" else s
    }

    fun applyOp(a: BigDecimal, b: BigDecimal, op: Operation): BigDecimal = when (op) {
        Operation.ADD -> a.add(b, mc)
        Operation.SUBTRACT -> a.subtract(b, mc)
        Operation.MULTIPLY -> a.multiply(b, mc)
        Operation.DIVIDE -> if (b.compareTo(BigDecimal.ZERO) == 0)
            BigDecimal.ZERO
        else
            a.divide(b, 12, RoundingMode.HALF_UP)
    }

    fun onDigit(d: Char) {
        state = if (state.clearOnNext) {
            state.copy(display = d.toString(), clearOnNext = false)
        } else {
            val newDisplay = if (state.display == "0") d.toString() else state.display + d
            state.copy(display = newDisplay)
        }
    }

    fun onDecimal() {
        if (state.clearOnNext) {
            state = state.copy(display = "0.", clearOnNext = false)
        } else if (!state.display.contains(".")) {
            state = state.copy(display = state.display + ".")
        }
    }

    fun onClearAll() {
        state = CalcState()
    }

    fun onDelete() {
        if (state.clearOnNext) return
        val s = state.display
        state = when {
            s.length > 1 -> state.copy(display = s.dropLast(1))
            else -> state.copy(display = "0")
        }
    }

    fun onPercent() {
        val value = toBD(state.display)
        val result = value.divide(BigDecimal(100), 12, RoundingMode.HALF_UP)
        state = state.copy(display = fmt(result))
    }

    fun onOperation(op: Operation) {
        val current = toBD(state.display)
        val acc = state.accumulator
        val pending = state.pendingOp
        val newAcc = when {
            acc == null -> current
            pending == null -> current
            state.clearOnNext -> acc // evita calcular si recién seleccionaste otra operación
            else -> applyOp(acc, current, pending)
        }
        state = state.copy(
            accumulator = newAcc,
            pendingOp = op,
            clearOnNext = true,
            display = if (acc == null) state.display else fmt(newAcc)
        )
    }

    fun onEquals() {
        val acc = state.accumulator
        val pending = state.pendingOp
        if (acc != null && pending != null) {
            val current = toBD(state.display)
            val result = applyOp(acc, current, pending)
            state = state.copy(
                display = fmt(result),
                accumulator = null,
                pendingOp = null,
                clearOnNext = true
            )
        }
    }

    CalculatorUI(
        display = state.display,
        onDigit = ::onDigit,
        onDecimal = ::onDecimal,
        onClearAll = ::onClearAll,
        onDelete = ::onDelete,
        onPercent = ::onPercent,
        onOpAdd = { onOperation(Operation.ADD) },
        onOpSub = { onOperation(Operation.SUBTRACT) },
        onOpMul = { onOperation(Operation.MULTIPLY) },
        onOpDiv = { onOperation(Operation.DIVIDE) },
        onEquals = ::onEquals
    )
}

@Composable
private fun CalculatorUI(
    display: String,
    onDigit: (Char) -> Unit,
    onDecimal: () -> Unit,
    onClearAll: () -> Unit,
    onDelete: () -> Unit,
    onPercent: () -> Unit,
    onOpAdd: () -> Unit,
    onOpSub: () -> Unit,
    onOpMul: () -> Unit,
    onOpDiv: () -> Unit,
    onEquals: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // Display
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.BottomEnd
        ) {
            Text(
                text = display,
                fontSize = 48.sp,
                fontWeight = FontWeight.Light,
                textAlign = TextAlign.End,
                lineHeight = 52.sp
            )
        }

        // Teclas
        val padModifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)

        Column(
            modifier = padModifier,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                CalcButton("AC", Modifier.weight(1f), onClearAll)
                CalcButton("⌫",  Modifier.weight(1f), onDelete)
                CalcButton("%",  Modifier.weight(1f), onPercent)
                CalcButton("÷",  Modifier.weight(1f), onOpDiv)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                CalcButton("7", Modifier.weight(1f)) { onDigit('7') }
                CalcButton("8", Modifier.weight(1f)) { onDigit('8') }
                CalcButton("9", Modifier.weight(1f)) { onDigit('9') }
                CalcButton("×", Modifier.weight(1f), onOpMul)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                CalcButton("4", Modifier.weight(1f)) { onDigit('4') }
                CalcButton("5", Modifier.weight(1f)) { onDigit('5') }
                CalcButton("6", Modifier.weight(1f)) { onDigit('6') }
                CalcButton("−", Modifier.weight(1f), onOpSub)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                CalcButton("1", Modifier.weight(1f)) { onDigit('1') }
                CalcButton("2", Modifier.weight(1f)) { onDigit('2') }
                CalcButton("3", Modifier.weight(1f)) { onDigit('3') }
                CalcButton("+", Modifier.weight(1f), onOpAdd)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                // "0" ancho doble
                CalcButton("0", Modifier.weight(2f)) { onDigit('0') }
                CalcButton(".", Modifier.weight(1f), onDecimal)
                CalcButton("=", Modifier.weight(1f), onEquals)
            }
        }
    }
}

@Composable
private fun CalcButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(64.dp)
    ) {
        Text(label, fontSize = 22.sp)
    }
}
